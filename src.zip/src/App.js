import './App.css';
import { FaFlagUsa } from "react-icons/fa";

function App() {
  return (
    <div className="wrapper">
      
         <div className="header">
          Header
          </div>  
         <div className="maincontent">
                    <div className="left">
                      <div className='totalSales'>
                      <span className='totalsalestext'> Total Sales </span>
                      <span className='hrr'> &nbsp;</span>
                       <span className='totalsalesvalue'>1,92,874,128 </span>
                      </div>
                     
                      <div className='customtable'>
                        
                      <table>
                        
  <caption> YTD August FY25 </caption>
  
  <thead>
    
    <tr>

      <th scope="col"></th>
      <th scope="col">Data 2</th>
      <th scope="col">Data 3</th>
      <th scope="col">Data 3</th>
      <th scope="col">Data 4</th>
    </tr>
  </thead>
  <tbody>
    <tr  >
      <td data-label="Data 1" >CONTENT 1</td>
      <td data-label="Data 2">Content 2</td>
      <td data-label="Data 3">Content 3</td>
      <td data-label="Data 3">Content 4</td>
      <td data-label="Data 4">Content 5</td>
    </tr>
    <tr>
      <td data-label="Data 1" >CONTENT 2</td>
      <td data-label="Data 2">Content 2</td>
      <td data-label="Data 3">Content 3</td>
      <td data-label="Data 3">Content 4</td>
      <td data-label="Data 4">Content 5</td>
    </tr>
    <tr>
      <td data-label="Data 1" >CONTENT 3</td>
      <td data-label="Data 2">Content 2</td>
      <td data-label="Data 3">Content 3</td>
      <td data-label="Data 3">Content 4</td>
      <td data-label="Data 4">Content 5</td>
    </tr>
    <tr>
      <td data-label="Data 1" >CONTENT 4</td>
            <td data-label="Data 2">Content 2</td>
      <td data-label="Data 3">Content 3</td>
      <td data-label="Data 3">Content 4</td>
      <td data-label="Data 4">Content 5</td>
    </tr>
  </tbody>
</table>


                      </div>



                <div className='boxescontainer'>
                    <div className='boxes box1'></div>
                    <div className='boxes box2'></div>
                    <div className='boxes box3'></div>
                    <div className='boxes box4'></div>
                </div>





                    </div>
                    
                    <div className="right_map">
                      <img src="/map.png"></img> 

 



                      <span className="mapinfo mapinfo_india">
                        
                       <div className='mapinfo_left' ><FaFlagUsa /></div>
                       
                       <div className='mapinfo_right' >
                       <div className='mapinfo_right_countrytext'> INDIA</div>
                       <div className='mapinfo_right_countryval'> INR 25.2 Cr</div>
                       </div>

                      </span>



                      <span className="mapinfo mapinfo_usa">
                        
                       <div className='mapinfo_left' ><FaFlagUsa /></div>
                       
                       <div className='mapinfo_right' >
                       <div className='mapinfo_right_countrytext'> USA</div>
                       <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                       </div>
                       
                      </span>



                       <span className="mapinfo mapinfo_uk">
                        
                       <div className='mapinfo_left' ><FaFlagUsa /></div>
                       
                       <div className='mapinfo_right' >
                       <div className='mapinfo_right_countrytext'> UK</div>
                       <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                       </div>
                       
                      </span>
 
                      <span className="mapinfo mapinfo_aus">
                        
                        <div className='mapinfo_left' ><FaFlagUsa /></div>
                        
                        <div className='mapinfo_right' >
                        <div className='mapinfo_right_countrytext'> AUSTRALIA</div>
                        <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                        </div>
                        
                       </span>


                       <span className="mapinfo mapinfo_phil">
                        
                        <div className='mapinfo_left' ><FaFlagUsa /></div>
                        
                        <div className='mapinfo_right' >
                        <div className='mapinfo_right_countrytext'> PHILIPPINES</div>
                        <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                        </div>
                        
                       </span>
                       
                      
                       <span className="mapinfo mapinfo_sa">
                        
                        <div className='mapinfo_left' ><FaFlagUsa /></div>
                        
                        <div className='mapinfo_right' >
                        <div className='mapinfo_right_countrytext'> SOUTH AFRICA</div>
                        <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                        </div>
                        
                       </span>
                      
                      
                       <span className="mapinfo mapinfo_ger">
                        
                        <div className='mapinfo_left' ><FaFlagUsa /></div>
                        
                        <div className='mapinfo_right' >
                        <div className='mapinfo_right_countrytext'> GERMANY </div>
                        <div className='mapinfo_right_countryval'>$ 25.2 Cr</div>
                        </div>
                        
                       </span>
                      
                      
                    </div>
          
          </div>  
          <div className="footer">
            Footer
          </div>  
        
    </div>
  );
}

export default App;
